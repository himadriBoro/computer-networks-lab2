////////////own
#include "string.h"
#include <unistd.h>
#include <sys/types.h>
#include "stdio.h"
#include <stdlib.h>
#include "netdb.h"
#include "netinet/in.h"
struct request
{
    char user[11];
    int itemNumber;
    int qty;
    int price;
    char type;      //B v S
    int id;
    int resolved;
    int notresolved;
};

struct userLog      //completed transactions (partially and wholly)
{
    char buyer[11];
    char seller[11];
    int itemNumber;
    int price;
    int qty;
    int buyRequestID;
    int sellRequestID;
     int log;
    char logdata[11];
    
};

struct request userRequests[5][1000];        //initial requests by users

int nRequest[5] = {0};

struct userLog tra_Log[5000];              //transactions completed, wholly or partially

int nTradeLog = 0;

int requestID=0;
struct request bqq[11][1000];

struct request sqq[11][1000];

int bhh[11]={0}, bt[11]={0}, shh[11]={0}, stt[11]={0};

void sortInsert(struct request);       //on basis of price then id

void removeItem(struct request);


unsigned int is_delim(char c, char *delim)
{
    while(*delim != '\0')
    {
        if(c == *delim)
            return 1;
        delim++;
    }
    return 0;
}



char *my_stok(char *srcString, char *delim)
{
    static char *backup_string; // start of the next search
    if(!srcString)
    {
        srcString = backup_string;
    }
    if(!srcString)
    {
        // user is bad user
        return NULL;
    }
    // handle beginning of the string containing delims
    while(1)
    {
        if(is_delim(*srcString, delim))
        {
            srcString++;
            continue;
        }
        if(*srcString == '\0')
        {
            // we've reached the end of the string
            return NULL; 
        }
        break;
    }
    char *ret = srcString;
    while(1)
    {
        if(*srcString == '\0')
        {
            /*end of the input string and
            next exec will return NULL*/
            backup_string = srcString;
            return ret;
        }
        if(is_delim(*srcString, delim))
        {
            *srcString = '\0';
            backup_string = srcString + 1;
            return ret;
        }
        srcString++;
    }
}








/////
void writeSock( int Sock, char *message )
{
    int m = write( Sock, message, strlen(message) );
    if (m < 0) 
      {
         perror("ERROR writing in to the socket");
         
      }
}

char **split_data(char *buff)
{
   int l = strlen(buff), tokens=1;
     int i=0;
   while( i<l)
   {
      if(buff[i]=='\n')
      {
         tokens++;
      }
      i++;
   }
   
   char *tokken;
   char **result;
   result = (char **)malloc(tokens * sizeof(char *));
   tokken = my_stok(buff, "\n");
   i=0;
   while(tokken!=NULL)
   {
      result[i] = (char *)malloc(sizeof(char)*strlen(tokken));
      strcpy(result[i], tokken);
      i++;
      tokken = my_stok(NULL, "\n");
   }
   return result;
}

// 1 means user and pass both match // 2 means correct user, wrong pass // 3 means both incorrect
int authenticationofuser( char *user, char *password, int *UserNum,int isvalid );


// compare requests
int compar(struct request l, struct request r) {
   if(l.price < r.price)
   { 
   return 1;
   }
   if(l.price == r.price)
   {
      return (l.id < r.id);
   }
   return 0;
}

// swap requests
void swapping(struct request *first, struct request *second) 
{
   struct request temp;
   temp = *second;
   *second = *first;
   *first = temp;
}

// Insert request in sorted order into the rigth queue
void insertionsort(struct request abc) 
{
  int *A1,*A2;
      struct request *ourarray = ( (abc.type=='B')?(bqq[abc.itemNumber]):(sqq[abc.itemNumber]) );
   if((abc.type == 'B'))
{
A1 = (bhh + abc.itemNumber);     
A2 = (bt + abc.itemNumber);
}
else
{
A1 =(shh + abc.itemNumber);
A2 =(stt + abc.itemNumber);
}
 
   if(*A1 == *A2) {
      ourarray[*A1] = abc;
      *A2 = (*A2 + 1)%1000;
   }
   else {
      int idx = *A1, i;
      while(!compar(abc, ourarray[idx]) && idx != *A2) {
         idx = (idx+1)%1000;
      }

      struct request temp = abc;
      for(i = idx; i != *A2; i = (i+1)%1000 ) {
         swapping(ourarray+i, &temp);
      }
      ourarray[*A2] = temp;
      *A2 = (*A2 + 1)%1000;
   }
   
}


int mstr(const char *buffer123, int Length1234, const char *sequence) ;



int main( int thearg, char *a12[] ) {
   
   char buffer[65536];
 char ip[] = "127.0.0.1";    
 struct sockaddr_in c_add, s_add;
   int  n;
  
   int s_1,portno, clilen, s_1new ;
   if(thearg<2)
   {
      fprintf(stderr,"usage %s port\n", a12[0]);
      exit(0);
   }


   s_1 = socket(AF_INET, SOCK_STREAM, 0);
   
   if (s_1 < 0) {
      perror("ERROR opening socket");
      exit(1);
   }
   

   bzero((char *) &s_add, sizeof(s_add));
   portno = atoi(a12[1]);
   
   s_add.sin_family = AF_INET;
   s_add.sin_addr.s_addr = INADDR_ANY;
   s_add.sin_port = htons(portno);
   
  
   if (bind(s_1, (struct sockaddr *) &s_add, sizeof(s_add)) < 0) {
      perror("ERROR on binding");
      exit(1);
   }

   
   listen(s_1,5);
   clilen = sizeof(c_add);
   
   while(1)
   {
        /* Accept actual connection from the client */
        s_1new = accept(s_1, (struct sockaddr *)&c_add, &clilen);
        if (s_1new < 0) {
            perror("ERROR on accept");
            continue;
        }
      
        /* If connection is established then start communicating */
        char buff[256];
        int offset = 0;
        
        while(1) {
            memset(buff, '\0', 256);
            int sz = read( s_1new, buff, 256);
            if(sz < 0) {
                printf("Error reading from socket\n");
                exit(-1);
        }
        memcpy(buffer+offset, buff, sz);
        offset += sz;
        if(mstr(buff, 256, "$$")) break;
    }
    buffer[offset] = '\0';
      
      
      
      
    printf("Here is the message:\n%s\n",buffer);
    char **mmssgg = split_data(buffer);
      
      
    if(strcmp(mmssgg[2], "LOGIN")==0)
    {
        
        int userNum;
        int res = authenticationofuser(mmssgg[0], mmssgg[1], &userNum,0);
        switch( res )
        {
            case 1:     
                writeSock( s_1new, "SUCCESS\nLOG IN Successful!\n") ;
                break;
            case 2:     
                writeSock(s_1new, "FAIL\nWrong Password!!!\nTry again\n");
                break;
            case 3: 
                writeSock(s_1new, "FAIL\nWrong username!!!\nTry again\n");
                break;
        }
    }
    else if(strcmp(mmssgg[2], "BUY")==0)
    {
        int userNum;
        int res = authenticationofuser(mmssgg[0], mmssgg[1], &userNum,0);
        if(res != 1)
        {
            writeSock( s_1new, "FAIL\nLOG IN UnSuccessful!\n") ;
            close(s_1new);
            continue;
        }
        int uusersname[5];
        for(int i=0;i<5;i++)
        {
             uusersname[i]=1;
        }
        /*construct the buy request structure*/
        int i;
        int item = atoi( mmssgg[3] );
        int qty =  atoi( mmssgg[4] );
        int unitPrice = atoi( mmssgg[5] );
        struct request buy;
        strcpy(buy.user, mmssgg[0]);
        buy.itemNumber = item;
        buy.qty = qty;
        buy.price = unitPrice;
        buy.id = requestID++;
        buy.type = 'B';
        //add to the initial user request log
        userRequests[userNum][ nRequest[ userNum ]++ ] = buy;
        //check if you get at least one seller
        int check =0;
        for(i=shh[item]; i != stt[item]; i = (i+1)%1000)          
        {
            if( sqq[item][i].price <= unitPrice )                     
            {
                if( sqq[item][i].qty >= buy.qty )                     
                {
                    check = 1;
                    sqq[item][i].qty -= buy.qty;                      
                    if(sqq[item][i].qty == 0)                         
                        shh[item] = (shh[item]+1)%1000;
                    
                    /*update the transaction log*/
                    
                    struct userLog tempLog; strcpy(tempLog.buyer, mmssgg[0]); strcpy(tempLog.seller, sqq[item][i].user); tempLog.itemNumber = item; 
                    tempLog.price = sqq[item][i].price; tempLog.qty = buy.qty; tempLog.buyRequestID = buy.id; 
                    tempLog.sellRequestID = sqq[item][i].id; tra_Log[nTradeLog++] = tempLog;
                    break;
                }
                else                                                        
                {
                    shh[item] = (shh[item]+1)%1000;                
                    buy.qty -= sqq[item][i].qty;                      
                    /*update the transaction log*/
                    struct userLog tempLog; strcpy(tempLog.buyer, mmssgg[0]); strcpy(tempLog.seller, sqq[item][i].user); tempLog.itemNumber = item; 
                    tempLog.price = sqq[item][i].price; tempLog.qty = sqq[item][i].qty; tempLog.buyRequestID = buy.id; 
                    tempLog.sellRequestID = sqq[item][i].id; tra_Log[nTradeLog++] = tempLog;
                }
            }
        }
      
        for(int i=0;i<5;i++)
        {
             uusersname[i]++;
        }
       
        if(check == 0)
            insertionsort(buy);
        
        writeSock(s_1new, "SUCCESS\n");
    }
    else if(strcmp(mmssgg[2], "SELL")==0)
    {
        int usernumber;
        int res = authenticationofuser(mmssgg[0], mmssgg[1], &usernumber,0);
        if(res != 1)
        {
            writeSock( s_1new, "FAIL\nLOG IN UnSuccessful!\n") ;
            close(s_1new);
            continue;
        }
        //////

    int queueusers[5];
     for(int i=0;i<5;i++)
    {
        queueusers[i]=i;
    }
    int isthere[5];
    for(int i=0;i<5;i++)
    {
        isthere[i]=i;
    }
     int gg=0;
     int s;
    while(gg<10)
    {
        
        s = queueusers[gg]-8;
        if(isthere[gg]==3)
        {
            break;
        }
        gg++;
 
    }

        int i;
        int item = atoi( mmssgg[3] );
        int qty =  atoi( mmssgg[4] );
        int unitPrice = atoi( mmssgg[5] );
        struct request sell;
        strcpy(sell.user, mmssgg[0]);
        sell.itemNumber = item;
        sell.qty = qty;
        sell.price = unitPrice;
        sell.id = requestID++;
        sell.type = 'S';
       
        userRequests[usernumber][ nRequest[ usernumber ]++ ] = sell;
        
           int un[5];
        for(int i=0;i<5;i++)
        {
             un[i]=1;
        }


        while( sell.qty > 0 )
        {
            if(bhh[item] == bt[item])          
            {
                insertionsort(sell);
                break;
            }
            int bestSell = bhh[item];
            //find index in buy queue with highest price in FCFS manner
            for(i=bhh[item]+1; i != bt[item]; i = (i+1)%1000)     
            {
                if( (bqq[item][i].price > bqq[item][bestSell].price) || ( (bqq[item][i].price == bqq[item][bestSell].price) && (bqq[item][i].id < bqq[item][bestSell].id) ) )
                    bestSell = i;
            }
            if( bqq[item][bestSell].price >= sell.price )              
            {
                if( bqq[item][bestSell].qty > sell.qty )              
                {
                    bqq[item][bestSell].qty -= sell.qty;               
                    /*construct the transaction and update*/
                    struct userLog tempLog; strcpy(tempLog.seller, mmssgg[0]); strcpy(tempLog.buyer, bqq[item][bestSell].user); tempLog.itemNumber = item; 
                    tempLog.price = sell.price; tempLog.qty = sell.qty; tempLog.buyRequestID = bqq[item][bestSell].id; 
                    tempLog.sellRequestID = sell.id; tra_Log[nTradeLog++] = tempLog;
                    
                    sell.qty = 0;
                    break;
                }
                else                                                        
                {
                    sell.qty -= bqq[item][bestSell].qty;               
                    /*update the trransaction log*/
                    struct userLog tempLog; strcpy(tempLog.seller, mmssgg[0]); strcpy(tempLog.buyer, bqq[item][bestSell].user); tempLog.itemNumber = item; 
                    tempLog.price = sell.price; tempLog.qty = bqq[item][bestSell].qty; tempLog.buyRequestID = bqq[item][bestSell].id; 
                    tempLog.sellRequestID = sell.id; tra_Log[nTradeLog++] = tempLog;
                    //remove the entry form buy queue
                    for( i=bestSell; i!=bt[item]; i=(i+1)%1000 )
                        bqq[item][i] = bqq[item][(i+1)%1000];
                    bt[item] = (1000+bt[item] - 1)%1000;
                }
            }
            else                                                            
            {
                insertionsort(sell);                                           
                break;
            }
        }
        writeSock(s_1new, "SUCCESS\n");
    }
 
    else if(strcmp(mmssgg[2], "VIEW_ORDERS")==0)
    {
        int i;
        char mesg[1000] = "\0";
        for(i=1; i<11; i++)
        {
            sprintf(mesg+strlen(mesg), "Item: %d\n", i);
            strcpy(mesg+strlen(mesg), "   total sell: ");

            if( shh[i] != stt[i] )
            {
                int t=shh[i];
                while(t!=stt[i])
                {
                
                
                sprintf(mesg+strlen(mesg), "qty- %d ;",sqq[i][t].qty );
                strcpy(mesg+strlen(mesg), ", ");
                sprintf(mesg+strlen(mesg), "price- %d ;", sqq[i][t].price);
                printf("\n");
                t++;
                t%=1000;
                }
            }
            else
                strcpy(mesg+strlen(mesg), "NA");
            strcpy(mesg+strlen(mesg), "\n");
              
            strcpy(mesg+strlen(mesg), "   Total Buy: ");
            if( bhh[i] != bt[i] )
            {  
                int t=bhh[i];
                while(t!=bt[i])
                {
                sprintf(mesg+strlen(mesg), "qty- %d ;", bqq[i][t].qty);
                strcpy(mesg+strlen(mesg), ",");
                sprintf(mesg+strlen(mesg), "price- %d ;", bqq[i][t].price);
                  t++;
                  t%=1000;
                }
            }
            else
                strcpy(mesg+strlen(mesg), "NA");
            strcpy(mesg+strlen(mesg), "\n");
        }
            int yyy[5];
        for(int i=0;i<5;i++)
        {
             yyy[i]=1;
        }


        writeSock(s_1new, "SUCCESS\n");
        writeSock(s_1new, mesg);
    }  
    else if(strcmp(mmssgg[2], "VIEW_TRADES")==0)
    {
        int userNum;
        int result = authenticationofuser(mmssgg[0], mmssgg[1], &userNum,0);
        printf("%s: %d\n", mmssgg[0], nRequest[userNum]);
        if(result != 1)
        {
            writeSock( s_1new, "FAIL\nLOG IN UnSuccessful!\n") ;
            close(s_1new);
            continue;
        }

           int yes[5];
        for(int i=0;i<5;i++)
        {
             yes[i]=1;
        }

        char sendmmssgg[1000];
        writeSock(s_1new, "SUCCESS\n");
        int i, j;
        for(j=0; j<nRequest[userNum]; j++)                                  
        {
            int getBuyID = userRequests[userNum][j].id;                    
            //print the initial request
            sprintf(sendmmssgg, "INITIAL REQUEST\n");
            writeSock(s_1new, sendmmssgg);
            sprintf(sendmmssgg, "%s %d %d %d %c %d\n", userRequests[userNum][j].user, userRequests[userNum][j].itemNumber, userRequests[userNum][j].qty, userRequests[userNum][j].price, userRequests[userNum][j].type, userRequests[userNum][j].id);
            writeSock(s_1new, sendmmssgg);
            sprintf(sendmmssgg, "(BUYER/SELLER, PRICE, ITEM, QTY, BUY_REQUEST_ID/SELL_REQUEST_ID)\n");
            writeSock(s_1new, sendmmssgg);
            for(i=0; i<nTradeLog; i++)                                     
            {
                if(tra_Log[i].buyRequestID == getBuyID)                   
                {
                    sprintf(sendmmssgg, "%s %s %d %d %d %d %d\n", tra_Log[i].buyer, tra_Log[i].seller, tra_Log[i].itemNumber, tra_Log[i].qty, tra_Log[i].price, tra_Log[i].buyRequestID, tra_Log[i].sellRequestID);
                    writeSock(s_1new, sendmmssgg);
                }
                else if(tra_Log[i].sellRequestID == getBuyID)             
                {
                    sprintf(sendmmssgg, "%s %s %d %d %d %d %d\n", tra_Log[i].buyer, tra_Log[i].seller, tra_Log[i].itemNumber, tra_Log[i].qty, tra_Log[i].price, tra_Log[i].buyRequestID, tra_Log[i].sellRequestID);
                    writeSock(s_1new, sendmmssgg);
                }
            }



        }
    }  
    close(s_1new);
   }
   return 0;
}

int authenticationofuser( char *user, char *password, int *UserNum,int isvalid )
{
    FILE *fp = fopen("login.txt", "r");
    char buff[50];
    *UserNum=0;
    while( fgets(  buff, sizeof(buff), fp) != NULL )
    {
        *UserNum += 1;
        char *user1 = my_stok(buff, ":");
        char *pass1 = my_stok(NULL, "\n");
       if( strcmp( user, user1) == 0 )
        {
            if( strcmp(password, pass1)==0)
            {
                isvalid =1;
               return 1;
            }   
            else
            { 
               return 2;
            }
        }
    }
    return 3;
}

int mstr(const char *buffer123, int Length1234, const char *sequence) {
   int i;
   for(i=0; i+strlen(sequence) < Length1234 ; i++) {
      if(memcmp(buffer123 + i, sequence, strlen(sequence)) == 0) {
         return 1;
      }
   }
   return 0;
}
