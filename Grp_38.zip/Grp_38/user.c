
#include <stdio.h>
#include <assert.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include<math.h>






static struct sockaddr_in server;


void rq(char *x,const char *f);




static char tid[201];




int success(const char *res) ;

char *seek(char *res) {
    char *pointer = res;
    while(*pointer != '\n') pointer++;
    pointer++;
    return pointer;
}

void new_add( const char *field,char *req) {
    strcat(req, field);
    strcat(req, "\n");
}
static char pass[201];

void printall()
{
        printf("Commands\n");
    printf("orders\n");
    printf("buy\n");
    printf("sell\n");
    printf("trades\n");
    printf("help\n");
}


void path(char *req) {
    new_add(tid,req);
   new_add(pass,req);
}
void printitem();

void printup();


void end_req(char *req) {
    strcat(req, "$$");
}

void view_req(int type) {
    char abc[65536];
    char xyz[65536];
    abc[0] = '\0';
    path(abc);
    new_add(((type==0)?("VIEW_ORDERS"):("VIEW_TRADES")),abc );
    end_req(abc);

    
    rq(xyz, abc);
    
    if(!success(xyz)) {
        printf("rq Failed\n");
        return;
    }

    printf("%s", seek(xyz)); 
}









void socket_add(int ula, const char *gh);

int buy_sell( int type, int up,int ic, int qn) {
     char fld[32];
   
    char res[65536];
    char abc[65536];
    abc[0] = '\0';
    path(abc);
    new_add( ((type==0)?("BUY"):("SELL")),abc );
    sprintf(fld, "%d", ic);
    new_add(fld,abc);
    sprintf(fld, "%d", qn);
    new_add(fld,abc);
    sprintf(fld, "%d", up);
    new_add(fld,abc);
    end_req(abc);

  
    rq(res, abc);
   
    if(success(res)) return 1;
    else return 0;
}



int aunthenticating(char *xyz) {
    char abc[65536];
    abc[0] = '\0';
    path(abc);
    new_add( "LOGIN",abc);
    end_req(abc);

    // send rq
    rq(xyz, abc);
    // check response
    if(success(xyz)) return 1;
    else return 0;
}

int main(int argc, char const *argv[])
{
    socket_add(atoi(argv[2]),argv[1] );

  
    while( 1 ) {
        char xyz[65536];
        printf("trader id: ");
        scanf("%s", tid);
        printf("password: ");
        scanf("%s", pass);

        if(aunthenticating(xyz)) {
            printf("%s", seek(xyz));
            break;
        }
        else {
            printf("%s", seek(xyz)); 
        }
    }

     printall();

   
    while( 1 ) {
        char hrgu[32];
       
        printf("Trade area ");
        scanf("%s", hrgu);
        int qn, up,ic ;
        if(strcmp(hrgu, "") == 0) continue;
      
else if(strcmp(hrgu, "sell") == 0) {
           
            printitem();
            scanf("%d", &ic);
 	 
	    printup();
            scanf("%d", &up);          
 	
            printf("Enter qn: ");
            scanf("%d", &qn);
           
            buy_sell(1,up,ic, qn);
        }
  
      else if(strcmp(hrgu, "buy") == 0) {
            printitem();
            scanf("%d", &ic);
            printup();
            scanf("%d", &up);            

            printf("qn: ");
            scanf("%d", &qn);
            
            buy_sell(0,up,ic, qn);
        }
        
	
	   else if(strcmp(hrgu, "trades") == 0) {
            view_req(1);
        }  
     
   else if(strcmp(hrgu, "orders") == 0) {
            view_req(0);
        }
     
        else if(strcmp(hrgu, "help") == 0) {
printall();
        }
        else {
            printf("Invalid command\n");
        }
    }

    
        
    return 0;
}









void socket_add( int port, const char *ip) {
    server.sin_addr.s_addr = inet_addr(ip);
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
}


void rq(char *xyz,const char *abc) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock == -1) {
        printf("Unable to create socket\n");
        exit(-1);
    }

    if( connect(sock, (struct sockaddr*)&server, sizeof(server)) < 0 ) {
        printf("Unable to connect to server\n");
        exit(-1);
    }

   
    if( send(sock, abc, strlen(abc), 0) < 0 ) {
        printf("Unable to send() to server\n");
        exit(-1);
    }

   
   
    int offset = 0;
 char *buffer[2048];   
 while( 1 ) {
        int size = recv(sock, buffer, 2048, 0);
        if(size > 0) {
            memcpy(xyz + offset, buffer, size);
            offset += size;
        }
        else {
            break;
        }
    }

    xyz[offset] = '\0';

}

int success(const char *res) {
    if(memcmp(res, "SUCCESS", 7) == 0) {
        return 1;
    }
    else {
        return 0;
    }
}
void printitem()
{
    printf("Item code: ");
}
void printup()
{
    printf("Unit Price: ");
}